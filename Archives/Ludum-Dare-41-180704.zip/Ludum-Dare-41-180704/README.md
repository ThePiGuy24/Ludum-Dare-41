# Ludum-Dare-41
run test.py
hold down left click to move car in direction of mouse
