import pygame
from random import randint
import os
import time
import math

red = (255,0,0)
green = (0,255,0)
darkGreen = (0,127,0)
blue = (0,0,255)
black = (0,0,0)
darkGrey = (64,64,64)
grey = (127,127,127)
white = (255,255,255)
pibotcolor = (52,152,219)
pibotbetacolor = (155,89,182)
xpos = 0
ypos = 0
xaxis = 0
yaxis = 0
angle = 0
realAngle = 0
eventCounter = 0

showVignette = False
showFps = False

width = 640
height = 480

velocity = 0

frames = []

print('Starting...')
pygame.init()

mainFont = pygame.font.Font('assets/fonts/PressStart2P.ttf', 16)
dispOut = pygame.display.set_mode((640,480))
clock = pygame.time.Clock()

pygame.display.set_caption('i failed this time, maybe next time...')

playerCar = pygame.image.load('assets/textures/playerCar.png')
vignette = pygame.image.load('assets/textures/vignette.png')
tiles = pygame.image.load('assets/textures/tiles.png')

def dispText(msg,color,posy,posx):
	textOut = mainFont.render(msg, True, color)
	dispOut.blit(textOut, [posx, posy])

def doNothing():
	variable = 0

def loadMap(mapFile):
	dispOut.fill(darkGrey)
	dispText("Loading Map...",white,height-26,0)
	file = open(mapFile).read()
	lines = file.split("\n")
	mapOut = []
	for lineNum in range(len(lines)):
		completion = (lineNum + 1) / len(lines)
		lineToAdd = []
		items = lines[lineNum].split(" ")
		for item in items:
			try:
				lineToAdd.append(int(item))
			except:
				doNothing
		mapOut.append(lineToAdd)
		dispOut.fill(white, rect=[0,height-10,completion*width,height])
		pygame.display.update()
	return mapOut

Exit = False

tileMap = loadMap("test.map")
map = pygame.Surface((len(tileMap)*32-32,len(tileMap[0])*32-32))
map.fill(white)

dispOut.fill(darkGrey)
dispText("Rendering Map...",white,height-26,0)
for line in range(len(tileMap)):
	completion = (line+1) / len(tileMap)
	for point in range(len(tileMap[line])):
		map.blit(tiles, [(line)*32,(point)*32], [(tileMap[line][point]%16)*32,(tileMap[line][point]//16)*32,32,32])
	dispOut.fill(white, rect=[0,height-10,completion*width,height])
	pygame.display.update()

yrot = [0,0.7,1,0.7,0,-0.7,-1,-0.7]
xrot = [1,0.7,0,-0.7,-1,-0.7,0,0.7]
			
while not Exit:
	t = time.time()
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			Exit = True
			print('Closing...')
		if event.type == pygame.MOUSEMOTION:
			mousey = event.pos[0] - width / 2
			mousex = event.pos[1] - height / 2
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_a or event.key == pygame.K_d:
				eventCounter = 0
			if event.key == pygame.K_v:
				showVignette = not showVignette
			if event.key == pygame.K_f:
				showFps = not showFps
			if event.key == pygame.K_r:
				xpos = 0
				ypos = 0
				xaxis = 0
				yaxis = 0
				angle = 0
				realAngle = 0
				eventCounter = 0
				velocity = 0
	
	if eventCounter > 0:
		eventCounter = eventCounter - 1
	
	if pygame.key.get_pressed()[pygame.K_UP] == 1 or pygame.key.get_pressed()[pygame.K_w] == 1:
		velocity = velocity + 0.7
	if pygame.key.get_pressed()[pygame.K_DOWN] == 1 or pygame.key.get_pressed()[pygame.K_s] == 1:
		velocity = velocity - 0.4
		 
	xpos = xpos + (xrot[angle] * velocity)
	ypos = ypos + (yrot[angle] * velocity)
	
	dispOut.fill((0,0,0,16))
	
	if velocity < 0:
		direction = -1
	else:
		direction = 1
	
	if abs(velocity) > 0.1:
		velocity = velocity * 0.95
		if eventCounter == 0:
			if pygame.key.get_pressed()[pygame.K_RIGHT] == 1 or pygame.key.get_pressed()[pygame.K_d] == 1:
				angle = angle + direction
				eventCounter = 10
			if pygame.key.get_pressed()[pygame.K_LEFT] == 1 or pygame.key.get_pressed()[pygame.K_a] == 1:
				angle = angle - direction
				eventCounter = 10
	else:
		velocity = 0

	angle = int(angle) % 8
		
	dispOut.blit(map, [(-ypos//2)*2,(xpos//2)*2])
	if pygame.key.get_pressed()[pygame.K_SPACE] == 1:
		map.blit(playerCar, [288+(ypos),208+(-xpos)],[angle*64,64,64,64])
		velocity = velocity * 0.9
	dispOut.blit(playerCar, [288,208],[angle*64,64,64,64])
	dispOut.blit(playerCar, [288,208],[angle*64,0,64,64])
	clock.tick(30)
	if showVignette:
		dispOut.blit(vignette, [0,0])
	if showFps:
		dispText(str(int(1/(time.time() - t))),white,0,0)
	pygame.display.update()

pygame.quit()
os.system('cls')
quit()
